nginx-rp
========

Cookbooks & Co., um `nginx` als Reverse Proxy aufzusetzen mit Chef.

