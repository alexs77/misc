nginx-rp
========

Cookbooks & Co., um `nginx` als Reverse Proxy aufzusetzen mit Chef.

:exclamation: :exclamation: **Hinweis 2017-06-23: Dies ist Work-In-Progress** :exclamation: :exclamation:

:heart_exclamation: :heart_exclamation: Dokumentation wird im [Wiki][wiki] aktuell gehalten! :heart_exclamation: :heart_exclamation:

License and Authors
-------------------
Authors: Alexander Skwar <alexander.skwar@everyware.ch>

---

[//]: Links

[wiki]: https://gitlab.unixsrv.everyware.zone/unix-intern/nginx-rp/wikis

