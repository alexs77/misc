zypper-test Cookbook
====================
Tests the zypper cookbook
