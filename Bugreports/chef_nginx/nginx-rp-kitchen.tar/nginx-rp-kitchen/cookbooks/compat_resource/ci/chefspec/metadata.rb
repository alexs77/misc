name 'test'
maintainer 'The Authors'
maintainer_email 'you@example.com'
license 'all_rights'
description 'Installs/Configures sk_test'
long_description 'Installs/Configures sk_test'
version '0.0.1'

depends "compat_resource"
