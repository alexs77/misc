name "unmodified"
description "does not depend on compat_resource directly"
version "1.0.0"
