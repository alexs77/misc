log "recipe" do
  action :nothing
end

resource "doit"
