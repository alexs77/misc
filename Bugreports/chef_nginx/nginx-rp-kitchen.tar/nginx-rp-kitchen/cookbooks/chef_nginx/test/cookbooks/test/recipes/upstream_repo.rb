apt_update 'update'

include_recipe 'test::_base'
include_recipe 'test::_test_site'
