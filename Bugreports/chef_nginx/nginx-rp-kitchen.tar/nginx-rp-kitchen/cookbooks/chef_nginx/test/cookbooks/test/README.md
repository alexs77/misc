Test cookbook for chef_nginx
