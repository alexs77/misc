#
# Cookbook Name:: empty
# Recipe:: default
#
# Copyright 2017, EveryWare
#
# All rights reserved - Do Not Redistribute
#

# Recipe, welches **NICHTS** macht.

# EOF
