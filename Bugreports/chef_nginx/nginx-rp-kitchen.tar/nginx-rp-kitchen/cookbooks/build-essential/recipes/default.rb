#
# Cookbook Name:: empty
# Recipe:: default
#
# All rights reserved - Do Not Redistribute
#

# Recipe, welches **NICHTS** macht.

# EOF
