# empty Cookbook

Ein "leeres" Cookbook.

Doku: Siehe [Wiki][wiki].

---

[//]: Links
[wiki]: https://gitlab.unixsrv.everyware.zone/cookbooks/empty/wikis/home
