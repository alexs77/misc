# empty Cookbook

Ein "leeres" Cookbook.

---

[//]: Links

