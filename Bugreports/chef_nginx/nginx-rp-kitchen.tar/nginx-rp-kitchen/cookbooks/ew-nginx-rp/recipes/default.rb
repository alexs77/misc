#
# Cookbook Name:: ew-nginx-lb
# Recipe:: default
#
# All rights reserved - Do Not Redistribute
#

# Konfiguriert System als nginx Reverse Proxy

include_recipe "chef_nginx::default"

# EOF
