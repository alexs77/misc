#
# Cookbook Name:: ew-nginx-lb
# Recipe:: default
#
# Copyright 2017, EveryWare AG
#
# All rights reserved - Do Not Redistribute
#

# Konfiguriert System als nginx Reverse Proxy

include_recipe "chef_nginx::default"

# EOF
