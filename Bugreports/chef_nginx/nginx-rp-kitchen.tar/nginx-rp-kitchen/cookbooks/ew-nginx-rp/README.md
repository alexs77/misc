ew-nginx-rp
===========

Wrapper Cookbook, um Nginx mit chef-nginx aufzusetzen.
